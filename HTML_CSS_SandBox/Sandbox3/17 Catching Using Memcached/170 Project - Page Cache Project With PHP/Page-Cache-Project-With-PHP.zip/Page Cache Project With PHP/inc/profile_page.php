<!DOCTYPE html>
<html>
<head>
	<title>My profile</title>
</head>
<body>
	<h1>My profile</h1>
	<p>Rest of page...</p>
</body>
</html>