//console.error('There was an error');

var foo = null;
if(foo != null){
    console.log(foo.length);
}

console.log(1);
console.log(2);
console.log(3);
console.log(4);
console.log(5);