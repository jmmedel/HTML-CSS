import { Component } from '@angular/core';

@Component({
    moduleId:module.id,
    selector: 'services',
    templateUrl: 'services.component.html'
})
export class ServicesComponent { }
