"use strict";
var Post = (function () {
    function Post() {
    }
    return Post;
}());
exports.Post = Post;
//# sourceMappingURL=Post.js.map