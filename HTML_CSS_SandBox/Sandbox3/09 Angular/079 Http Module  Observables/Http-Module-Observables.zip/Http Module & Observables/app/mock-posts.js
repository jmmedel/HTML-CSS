"use strict";
exports.POSTS = [
    { id: 1, title: 'Post One', body: 'This is body one' },
    { id: 1, title: 'Post Two', body: 'This is body two' },
    { id: 1, title: 'Post Three', body: 'This is body three' },
    { id: 1, title: 'Post Four', body: 'This is body four' }
];
//# sourceMappingURL=mock-posts.js.map