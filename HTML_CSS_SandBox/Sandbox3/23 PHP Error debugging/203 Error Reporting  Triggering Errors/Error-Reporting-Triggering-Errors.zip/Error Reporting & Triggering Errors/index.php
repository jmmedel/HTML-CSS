<?php
	// error_reporting(0); // Show No Errors
	// error_reporting(-1); // Show All Errors
	// error_reporting(E_ALL); // Show All Errors
	// error_reporting(E_ALL & ~E_NOTICE); // Show All Errors Except Notices
	//ini_set('display_errors', 'on');

	//echo test;
	//echo $test;
	//myfunc();
	//echo 'Hi There'
	//include 'test.php';

	//trigger_error('This is a fatal error',E_USER_ERROR);
	//trigger_error('This is a notice',E_USER_NOTICE);
	//trigger_error('This is a warning',E_USER_WARNING);
	echo 'Hello World';